"""Portable RTCP development core. No live printer transport is provided."""

__version__ = "0.1.0"
LIVE_EXECUTION_SUPPORTED = False
