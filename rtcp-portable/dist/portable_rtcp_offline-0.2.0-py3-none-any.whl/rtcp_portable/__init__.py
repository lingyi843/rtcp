"""Portable RTCP development core. No live printer transport is provided."""

__version__ = "0.2.0"
LIVE_EXECUTION_SUPPORTED = False
